package co.edu.uptc.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class Cities{
    private String name;
    private String country;
    private int population;
    private float altitude;

    @Override
    public String toString() {
        return "Nombre: " + name + 
                " | Pais: " + country +
                " | Población: " + population +
                " | Altitud: " + altitude;
    }
}