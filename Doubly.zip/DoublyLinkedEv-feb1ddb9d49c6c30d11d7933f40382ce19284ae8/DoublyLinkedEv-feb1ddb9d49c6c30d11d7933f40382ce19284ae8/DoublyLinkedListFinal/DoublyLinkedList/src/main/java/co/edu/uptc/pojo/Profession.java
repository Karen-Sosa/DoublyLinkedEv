package co.edu.uptc.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class Profession{
    private int id;
    private String name;
    private String kind;
    private double salary;

    @Override
    public String toString() {
        return "ID: " + id + 
                " | Nombre: " + name +
                " | Área: " + kind +
                " | Salario: " + salary;
    }
}