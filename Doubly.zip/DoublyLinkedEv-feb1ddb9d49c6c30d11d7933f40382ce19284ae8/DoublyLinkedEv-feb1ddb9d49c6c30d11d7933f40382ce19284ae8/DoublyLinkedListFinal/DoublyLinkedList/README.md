# Lista Doblemente Enlazada

Aplicación en Java para gestionar registros de personas usando una lista doblemente enlazada implementada desde cero.
El proyecto permite dividir los registros según un criterio de edad, eliminar registros que cumplan dicho criterio y ordenar la información utilizando Selection Sort, todo trabajando directamente sobre nodos enlazados sin depender de las colecciones de Java.

